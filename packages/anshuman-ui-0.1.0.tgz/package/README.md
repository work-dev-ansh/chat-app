# Anshuman UI

A small, accessible, reusable React component library built with TypeScript and CSS design tokens.

## Included in this starter

- `Button` with variants, sizes, loading and disabled states
- `Input` and `Textarea` with labels, hints and error messages
- `Badge`, `Avatar`, `Card`, `Spinner`, and `Alert`
- CSS custom-property design tokens and light/dark theme support
- Strict TypeScript, Vitest, React Testing Library, Storybook, and a production build
- Vite playground for quick local visual checks

## Requirements

Node.js 20+ recommended.

## Install and run the playground

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Validate the library

```bash
npm run typecheck
npm test
npm run build
npm run storybook
```

## Use from another local project

Build the library first:

```bash
npm run build
```

Then, from your consuming app (for example `simu-chat-practice`), install the local folder:

```bash
npm install ../anshuman-ui
```

Adjust the relative path if the two repositories are in a different location. Import the styles once in the app's global CSS or root entry:

```tsx
import "@anshuman/ui/styles.css";
import { Button, Input } from "@anshuman/ui";
```

Example:

```tsx
<Input label="Message" placeholder="Write a message..." />
<Button variant="primary">Send message</Button>
```

When developing the library and app together, rebuild the library after source changes. For a smoother linked workflow, you can use `npm link`, but a local folder dependency is usually simpler and more reproducible for an assessment.

## Component principles

- Components are UI-only: they do not fetch data, know about a backend, or own application state beyond small interaction details.
- Public props are typed and intentionally small.
- Native HTML attributes are forwarded where appropriate.
- Error states use visible text and `aria-describedby`.
- Colors and spacing are tokens, so products can theme the components.
- Do not treat TypeScript as runtime validation for data coming from an API or WebSocket.

## Publishing later

Before publishing to npm, check whether the desired package name is available and review all metadata. This starter is configured for local installation; it has not been published.
